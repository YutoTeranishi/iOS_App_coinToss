# Contributing
You want to contribute? Thank you :smila:

1. Clone the repositoy: `git clone git@github.com:bahlo/SwiftGif.git`
2. Create a new branch with the schema `my-feature`.
3. Implement your feature
4. Open a pull request

:heart:

