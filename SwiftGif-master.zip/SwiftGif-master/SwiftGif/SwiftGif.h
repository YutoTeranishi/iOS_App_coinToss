//
//  SwiftGif.h
//  SwiftGif
//
//  Created by Arne Bahlo on 22.08.16.
//  Copyright © 2016 Arne Bahlo. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SwiftGif.
FOUNDATION_EXPORT double SwiftGifVersionNumber;

//! Project version string for SwiftGif.
FOUNDATION_EXPORT const unsigned char SwiftGifVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftGif/PublicHeader.h>


